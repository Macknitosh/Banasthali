package com.dignifiedlives.medha.banasthali;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.app.Activity;
import android.widget.ImageView;
import android.widget.TextView;


public class Bean extends ArrayAdapter<String> {
    private final Activity context;
    private final String[]numbers;
    private final Integer[] imgid;

    public Bean(Activity context,String[] numbers,Integer[] imgid) {
        super(context,R.layout.listtext,numbers);
        this.context = context;
        this.numbers = numbers;
        this.imgid=imgid;
    }
    public View getView(int position ,View view,ViewGroup parent){
       LayoutInflater inflater = context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.listtext, null, true);

        TextView txt = (TextView)rowView.findViewById(R.id.ItemName);
        ImageView imageView = (ImageView)rowView.findViewById(R.id.icon);
        txt.setText(numbers[position]);
        imageView.setImageResource(imgid[position]);
        return rowView;

    };
}