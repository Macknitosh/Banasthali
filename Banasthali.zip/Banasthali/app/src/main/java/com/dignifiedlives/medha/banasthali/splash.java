package com.dignifiedlives.medha.banasthali;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;

public class splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        ImageView img = (ImageView) findViewById(R.id.imageView1);
        TranslateAnimation animation = new TranslateAnimation(0.0f, 0.0f, 100.0f, 0.0f);
        animation.setDuration(1000);
        animation.setRepeatCount(0);
        animation.setRepeatMode(2);
        animation.setFillAfter(true);
        img.startAnimation(animation);
        Thread timer = new Thread() {
            public void run() {
                try {
                    sleep(2000);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    Intent open = new Intent(splash.this, Next.class);
                    startActivity(open);
                }
            }

        };
        timer.start();

        }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}

