package com.dignifiedlives.medha.banasthali;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class Banasthali extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    ListView mainListView;
    String[] numbers ={"Banasthali Vidyapeeth ","Parent Login", "Student Login"};
    Integer[] imgid = {R.mipmap.ic_center,R.mipmap.ic_parent,R.mipmap.ic_student};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banasthali);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ArrayAdapter<String> listAdapter;

        Bean adapt = new Bean(this,numbers,imgid);
        mainListView = (ListView) findViewById(R.id.listView);
        mainListView.setAdapter(adapt);


        //change in database and then  on click listitem change the database then open the intent next
        mainListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String liste = String.valueOf((adapterView.getItemAtPosition(i)));
                Toast.makeText(Banasthali.this,"Login Pages",Toast.LENGTH_LONG).show();
                if(i>=0)
                {
                    String find = (String)adapterView.getItemAtPosition(i);
                    Bundle basket = new Bundle();
                    basket.putString("key",find);
                    Intent x =new Intent(Banasthali.this, splash.class);
                    x.putExtras(basket);
                    startActivity(x);
                }
            }
        });



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.banasthali, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
          switch(id)
          {
              case R.id.nav_send:
              {      String email[] ={"banasthali.org"};
                  Intent emailIntent =new Intent(android.content.Intent.ACTION_SEND);
                   emailIntent.setType("plain/text");
                  emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, email);
                  emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "FeedBack");

                  emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,"Message:");
                  startActivity(emailIntent);
                break;
              }
              case R.id.nav_call:{

                      Intent call=new Intent(Intent.ACTION_CALL);
                      call.setData(Uri.parse("tel:8094876520"));
                  try{
                      startActivity(call);
                  }catch(ActivityNotFoundException e){
                      Toast.makeText(Banasthali.this,"Call Failed",Toast.LENGTH_SHORT).show();
                      e.printStackTrace();
                  }

                break;
              }

          }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
